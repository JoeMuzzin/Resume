In this Course Project, I will be using the covid tracking API and using a URL connection to recieve the JSON data and get the fields for display. 

Doccomments have been spread throughout the program entirely to help understand my thought process on the coding.

I have used JSON data from the covidtracking API, and with JSON-B i have connected the data with java objects.

I have created a GUI so that others may interract with the data in to see the current data of any state they desire, as well as request different data from swing as well.

The data that you wish to save locally from different states will be added to a txtfile inside the program called serialx.txt.

I have used SwingWorkers to make sure the API calls don't slow down the swing interface.


*This program has been written by Joseph Muzzin*
